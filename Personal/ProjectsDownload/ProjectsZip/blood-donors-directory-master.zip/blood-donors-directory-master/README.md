**Blood Donors Directory**

[![Build Status](https://travis-ci.org/akhilputhiry/blood-donors-directory.svg?branch=master)](https://travis-ci.org/akhilputhiry/blood-donors-directory) [![PyPi](https://img.shields.io/pypi/v/blood-donors-directory.svg)](https://pypi.python.org/pypi/blood-donors-directory/) [![License](https://img.shields.io/pypi/l/blood-donors-directory.svg)](https://github.com/akhilputhiry/blood-donors-directory/blob/master/LICENSE.txt) [![Codecov](https://img.shields.io/codecov/c/github/akhilputhiry/blood-donors-directory.svg)](https://codecov.io/gh/akhilputhiry/blood-donors-directory) [![Docs](https://readthedocs.org/projects/blood-donors-directory/badge/?version=latest)](http://blood-donors-directory.readthedocs.io) [![Code Health](https://landscape.io/github/akhilputhiry/blood-donors-directory/master/landscape.svg?style=flat)](https://landscape.io/github/akhilputhiry/blood-donors-directory/master)

Many colleges and organizations are having blood donors forum/group within their organization these days. This project is a small application intented to help these organization in maintaining their database.

Features:
* Donor database
* Donor search
* Donation register
* Post donation requests in social media/organizations pages

