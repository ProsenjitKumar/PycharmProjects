from django.apps import AppConfig


class SiyamPortfolioConfig(AppConfig):
    name = 'siyam_portfolio'
