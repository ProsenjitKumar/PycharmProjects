default_app_config = 'rename_forward.apps.TestApp'
