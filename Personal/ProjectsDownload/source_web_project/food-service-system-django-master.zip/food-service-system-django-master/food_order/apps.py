from django.apps import AppConfig


class FoodOrderConfig(AppConfig):
    name = 'food_order'
