from django.apps import AppConfig


class NewslettersConfig(AppConfig):
    name = 'newsletters'
