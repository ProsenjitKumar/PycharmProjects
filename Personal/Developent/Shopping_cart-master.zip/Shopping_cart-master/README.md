A basic shopping cart for digital products using Stripe payments.

*To Start*: Create a stripe account and put your stripe publishable key and secret key inside `settings.py` as well as your publishable key inside `checkout.js` in the static folder. Follow the tutorial here for working with the shopping cart: https://youtu.be/6aQanCJZx04. Follow this tutorial to see how to setup payments with Braintree: 

The password for the admin user is `matt1234`.

[![alt text](https://github.com/justdjango/Shopping_cart/blob/master/static_root/images/cart.png "Logo")](https://justdjango.com)

# Where to find us
Like us on [Facebook](https://www.facebook.com/justdjangocode/)

Follow us on [Instagram](https://www.instagram.com/justdjangocode/)

Subscribe to our [YouTube](https://www.youtube.com/channel/UCRM1gWNTDx0SHIqUJygD-kQ) Channel

Or visit our [Website](https://www.justdjango.com) to sign up for our news letter (with discount codes for future courses)