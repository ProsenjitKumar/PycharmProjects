"""Couple django-generic-m2m and django-queryset-sequence for DAL."""
