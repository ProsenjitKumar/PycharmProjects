from __future__ import absolute_import

from .test_subscriptions import SubscriptionTest  # noqa
