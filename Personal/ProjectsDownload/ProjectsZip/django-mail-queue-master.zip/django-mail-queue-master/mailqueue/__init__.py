VERSION = '3.1.5'

default_app_config = 'mailqueue.apps.MailQueueConfig'
