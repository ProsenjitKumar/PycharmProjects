from django.apps import AppConfig


class UserReviewsConfig(AppConfig):
    name = 'user_reviews'
