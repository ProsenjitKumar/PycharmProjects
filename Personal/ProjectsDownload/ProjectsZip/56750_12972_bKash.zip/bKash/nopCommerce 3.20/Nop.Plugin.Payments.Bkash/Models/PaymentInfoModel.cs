﻿using Nop.Web.Framework.Mvc;

namespace Nop.Plugin.Payments.Bkash.Models
{
    public class PaymentInfoModel : BaseNopModel
    {
        public string DescriptionText { get; set; }
    }
}