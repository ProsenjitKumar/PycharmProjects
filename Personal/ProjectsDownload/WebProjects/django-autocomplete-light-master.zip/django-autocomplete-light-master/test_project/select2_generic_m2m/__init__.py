default_app_config = 'select2_generic_m2m.apps.TestApp'
