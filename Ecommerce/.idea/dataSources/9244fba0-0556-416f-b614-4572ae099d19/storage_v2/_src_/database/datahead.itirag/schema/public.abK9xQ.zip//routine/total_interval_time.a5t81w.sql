create function total_interval_time() returns trigger
    language plpgsql
as
$$
declare
current_interval interval := sum(interval_time) from employee where pid = new.pid and today = current_date;
history_total_interval interval := sum(new_interval_time) from history where log_date = current_date and pid = new.pid;

    begin
	new.total_interval_time := current_interval + history_total_interval;
	--new.total_interval_time := sum(new_interval_time) from history where log_date = current_date and pid = new.pid;
        return new;
    end;
$$;

alter function total_interval_time() owner to prosenjit;

