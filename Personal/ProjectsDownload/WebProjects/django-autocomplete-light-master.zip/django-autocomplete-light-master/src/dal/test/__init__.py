"""Test utils for autocompletes."""
