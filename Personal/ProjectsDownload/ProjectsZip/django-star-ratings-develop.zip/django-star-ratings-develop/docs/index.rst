.. include:: ../README.rst

Bugs and feature requests
-------------------------

    https://github.com/wildfish/django-star-ratings/issues

Created by `Wildfish <http://wildfish.com/>`_ and contributors.
