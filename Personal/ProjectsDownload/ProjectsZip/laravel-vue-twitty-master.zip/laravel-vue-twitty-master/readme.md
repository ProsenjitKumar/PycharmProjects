## Simple Twitter Clone

### Screenshots

## Home page
<img src="screenshots/one.png" height="500">

## Retweet
<img src="screenshots/two.png" height="500">

## Profile edit
<img src="screenshots/three.png" height="500">

## Change password
<img src="screenshots/four.png" height="500">
