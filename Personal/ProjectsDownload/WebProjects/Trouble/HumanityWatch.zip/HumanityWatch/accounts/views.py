from datetime import timezone

from django.contrib import messages
from rest_framework import filters
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render, redirect
#from django.views.generic import CreateView, FormView
from django.utils.http import is_safe_url
#from py2exe.boot_service import password
from django.views.decorators.csrf import csrf_protect
from .forms import RegisterForm, LoginForm, GuestForm, UserForm, LastDonationChangeForm
from .models import Profile
from django.db.models import Q



def home(request):
    queryset = User.objects.all()

    filter_backends = (filters.SearchFilter,)
    search_fields = ('full_name', 'email')

    return render(request, 'accounts/home.html')


@csrf_protect
def login_page(request):
    form = LoginForm(request.POST or None)
    context = {"form": form}
    next_ = request.GET.get('next')
    next_post = request.POST.get('next')
    redirect_path = next_ or next_post or None
    if form.is_valid():
        username = form.cleaned_data.get("username")
        password = form.cleaned_data.get("password")
        user = authenticate(request, username=username, password=password)
        #user.active = False
        if user is not None:
            # Is the account active? It could have been disabled.
            # user.is_active = False
            if user.is_active:
                login(request, user)
                return render(request, 'accounts/profile.html')
                #return HttpResponseRedirect("/profile/")
            else:
                return HttpResponse("You have to Wait for admin approval.")
        else:
            print("Invalid login details: {0}, {1}".format(username, password))
            return render(request, 'accounts/pass_admin_approval_wrong.html')
    else:
        return render(request, 'accounts/login.html', context)


User = get_user_model()
@csrf_protect
def register_page(request):
    form = RegisterForm(request.POST or None)
    context = {
        "form": form
    }
    if form.is_valid():
        form.save()
        return render(request, 'accounts/register_success.html')
    return render(request, 'accounts/register.html', context)


@login_required
def profile(request):
    args = {"user": request.user }

    return render(request, 'accounts/profile.html', args)



@login_required
def info(request):

    args = {
        "user": request.user,
        #"profile_user": request.user_
    }
    return render(request, 'accounts/info.html', args)


@login_required
def user_logout(request):
    # Since we know the user is logged in, we can now just log them out.
    logout(request)

    # Take the user back to the homepage.
    return HttpResponseRedirect('/')


def contact_us(request):
    return render(request, 'contact.html')


def about(request):
    return render(request, 'about.html')


def mission(request):
    return render(request, 'mission.html')


def available_donor(request):
    #today = timezone.now().date()
    # queryset_list = User.objects.all()
    # if request.user.is_staff or request.user.is_superuser:
    #     queryset_list = User.objects.all()
    #
    # query = request.GET.get("q")
    # if query:
    #     queryset_list = queryset_list.filter(
    #         Q(full_name__startswith='p')|
    #         Q(email__startswith='p')
    #     )
    # paginator = Paginator(queryset_list, 2)
    # page_request_var = "page"
    # page = request.GET.get(page_request_var)
    # try:
    #     queryset = paginator.page(page)
    # except PageNotAnInteger:
    #     queryset = paginator.page(1)
    # except EmptyPage:
    #     queryset = paginator.page(paginator.num_pages)
    if request.method == 'POST':
        search = request.POST['search']

        if search:
            match = User.objects.filter(
                Q(full_name__startswith=search) |
                Q(email__icontains=search) |
                Q(blood__startswith=search) |
                Q(first_address__icontains=search)
            )
            if match:
                return render(request, 'available_donor.html', {"match": match})
            else:
                messages.error(request, "No result found")
        else:
            return HttpResponseRedirect('/')

    args = {
        #"user": request.user,
        "users": User.objects.all(),
    }
    return render(request, 'available_donor.html', args)


# def base(request):
#     return render(request, 'index.html')

def last_donation_date(request):
    form = LastDonationChangeForm(request.POST or None)
    users = request.user.history.all()
    context = {
        "form": form,
        "users": users,
    }
    if form.is_valid():
        form.save(commit=False)
        return render(request, 'accounts/register_success.html')
    return render(request, 'accounts/last_donation_date.html', context)







