Original author:

* Eric Florenzano (@ericflo)

Maintainers:

* Honza Král (@HonzaKral)
* Diederik van der Boor (@vdboor)

Contributions by:

* Adam Fast (@adamfast)
* Cameron Spencer (@eusonic)
* Charles Leifer (@coleifer)
* Christos Trochalakis <yatiohi@ideopolis.gr>
* Dominika Krejčí
* Edward Betts
* Egor Yurtaev (@yurtaev)
* Felix Boehme
* Flavio Curella (@fcurella)
* Francisco Albarran (@pahko)
* Glen Baker (@iepathos)
* Jakub Vysoký (@kvbik)
* Jannis Leidel (@jezdez)
* Jayaseelan Yezhuaralai (@yrcjaya)
* Joshua Bonnett (@Jbonnett)
* Juan Pablo Puerta <ewsews@gmail.com>
* Kevin Fricovsky <kevin@howiworkdaily.com>
* Lars Rinn
* Matthijs Kooijman <matthijs@stdin.nl>
* Max Battcher <me@worldmaker.net>
* Michael Blume
* Nik Nyby
* Pavel Blinov <pahaz.blinov@gmail.com>
* The World Company (@worldcompany)
* Thejaswi Puthraya <http://thejaswi.info/>
* Vadim Markovtsev
* @SushiTee
* @pahaz
