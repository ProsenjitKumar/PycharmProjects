from django.apps import AppConfig


class FoodNewslettersConfig(AppConfig):
    name = 'food_newsletters'
