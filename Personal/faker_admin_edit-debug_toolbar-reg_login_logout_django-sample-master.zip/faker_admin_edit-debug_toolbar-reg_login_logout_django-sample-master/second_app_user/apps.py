from django.apps import AppConfig


class SecondAppUserConfig(AppConfig):
    name = 'second_app_user'
