1. 'Nop.Plugin.Payments.Bkash' directory contains source code.
2. 'Payments.Bkash' contains binaries. Just drop it into \Plugins directory on your server.