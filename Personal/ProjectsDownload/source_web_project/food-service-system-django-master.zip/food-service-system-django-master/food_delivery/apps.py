from django.apps import AppConfig


class FoodDeliveryConfig(AppConfig):
    name = 'food_delivery'
