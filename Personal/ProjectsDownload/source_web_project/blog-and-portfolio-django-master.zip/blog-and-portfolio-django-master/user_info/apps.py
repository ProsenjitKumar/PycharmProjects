from django.apps import AppConfig


class User_infoConfig(AppConfig):
    name = 'user_info'
