from django.apps import AppConfig


class FoodUsersProfileConfig(AppConfig):
    name = 'food_users_profile'
