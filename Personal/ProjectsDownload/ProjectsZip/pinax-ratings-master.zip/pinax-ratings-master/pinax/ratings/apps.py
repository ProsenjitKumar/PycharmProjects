from django.apps import AppConfig as BaseAppConfig


class AppConfig(BaseAppConfig):

    name = "pinax.ratings"
    verbose_name = "Pinax Ratings"
