from django.apps import AppConfig


class FoodProvidersConfig(AppConfig):
    name = 'food_providers'
