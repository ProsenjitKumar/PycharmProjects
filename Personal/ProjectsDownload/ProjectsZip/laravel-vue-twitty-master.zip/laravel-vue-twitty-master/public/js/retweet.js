$(function () {
    // $('.retweet-popup').hide();
    // $(document).on('click', '.retweet', function () {
    //     $('.retweet-popup').show();
    //     let tweet_id = $(this).data('tweet');
    //     let user_id = $(this).data('user');
    //
    //     let counter = $(this).find('.retweetsCount');
    //     let count = counter.text();
    //     $btn = $(this);
    // });
    //
    // $('.close-retweet-popup').click(function () {
    //     $('.retweet-popup').hide();
    // });
});