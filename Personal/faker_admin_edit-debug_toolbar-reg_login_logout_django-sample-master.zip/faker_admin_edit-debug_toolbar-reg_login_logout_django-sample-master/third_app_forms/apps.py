from django.apps import AppConfig


class ThirdAppFormsConfig(AppConfig):
    name = 'third_app_forms'
