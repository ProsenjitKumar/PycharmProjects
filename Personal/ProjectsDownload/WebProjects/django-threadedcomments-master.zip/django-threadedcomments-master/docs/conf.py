extensions = ['sphinx.ext.autodoc']
templates_path = ['.templates']
source_suffix = '.txt'
master_doc = 'index'

# General information about the project.
project = u'Django threaded comments'

