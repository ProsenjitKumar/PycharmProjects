from test_plus.test import TestCase as PlusTestCase


class TestCase(PlusTestCase):
    pass
