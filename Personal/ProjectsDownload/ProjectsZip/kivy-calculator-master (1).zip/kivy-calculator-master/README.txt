This is a simple calculator app created with Kivy.

Brendan Roddy