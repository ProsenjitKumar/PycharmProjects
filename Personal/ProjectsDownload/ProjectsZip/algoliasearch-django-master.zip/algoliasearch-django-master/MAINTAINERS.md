## `algolia/algoliasearch-django` maintainers

| Name            | Email               |
|-----------------|---------------------|
| Paul-Louis Nech | support@algolia.com |
