str = "0000000this is string example....wow!!!0000000";
print(str.strip('0'))

