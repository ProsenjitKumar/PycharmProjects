from django.apps import AppConfig


class TwittyConfig(AppConfig):
    name = 'twitty'
