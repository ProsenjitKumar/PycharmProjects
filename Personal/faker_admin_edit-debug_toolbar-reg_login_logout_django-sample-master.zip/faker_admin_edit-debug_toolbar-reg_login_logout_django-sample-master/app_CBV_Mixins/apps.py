from django.apps import AppConfig


class AppCbvMixinsConfig(AppConfig):
    name = 'app_CBV_Mixins'
