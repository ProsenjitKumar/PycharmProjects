from django.apps import AppConfig


class FourthAppRegLoginLogoutConfig(AppConfig):
    name = 'fourth_app_reg_login_logout'
