# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import unicode_literals

API_ROOT_URL = "https://api.yelp.com"

BUSINESS_PATH = "/v3/businesses/{business_id}"
PHONE_SEARCH_PATH = "/v3/businesses/search/phone"
SEARCH_PATH = "/v3/businesses/search"
